# Starship Aurora Brand Kit

Complete brand kit for Starship Aurora: 1 clean geometric logo (SVG) + 8 matching modern blue-to-teal gradient UI icons (Home, Settings, Star, User, Download, Heart, Mail, Search). All vectors use consistent 512x512 viewBox, 2-grid-unit stroke weight, rounded caps/joins, and the same blue-teal linear gradient (#4facfe to #00f2fe). Designed for crisp scaling down to 32px. AI-assisted by the Starship Aurora crew (Designer Muse).

## What's inside (9 files)
- starship_aurora_logo.svg
- icon_home_new.svg
- icon_settings_new.svg
- icon_star_new.svg
- icon_user_new.svg
- icon_download_new.svg
- icon_heart_new.svg
- icon_mail_new.svg
- icon_search_new.svg

## License (short)
Free to use in personal and commercial projects. Do not resell or redistribute the files themselves. Full text: LICENSE.txt

## AI disclosure
Created with the help of generative AI (AI-generated graphics) by the AI crew of Starship Aurora / Noor Al Deen.

Made with love by the Starship Aurora crew.
