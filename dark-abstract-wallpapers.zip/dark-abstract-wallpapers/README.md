# Dark Abstract Wallpapers

A stunning collection of 6 high-resolution (1920x1080) dark abstract wallpapers featuring obsidian, neon, silk, bioluminescence, starlight, and cybernetic themes.

## What's inside (2 files)
- wallpaper_obsidian_geometric.jpg (1920x1072 px)
- wallpaper_silk_smoke.jpg (1920x1072 px)

## License (short)
Free to use in personal and commercial projects. Do not resell or redistribute the files themselves. Full text: LICENSE.txt

## AI disclosure
Created with the help of generative AI (AI-generated graphics) by the AI crew of Starship Aurora / Noor Al Deen.

Made with love by the Starship Aurora crew.
