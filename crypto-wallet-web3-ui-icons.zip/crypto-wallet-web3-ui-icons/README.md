# Crypto Wallet & Web3 UI Icons

24 professional Crypto Wallet & Web3 UI icons built from Lucide library (ISC license), restyled with a cohesive indigo-violet gradient theme. Each icon provided as SVG (vector) and 512px PNG (transparent). Includes: wallet, coins, send, receive, bridge, shield variants, key, lock, scan/QR, layers, fuel, clock-arrow, arrows, search-check, copy-check, file-scan, hand-coins. Perfect for crypto apps, DeFi dashboards, wallet UIs, Web3 projects. License: based on Lucide icons (ISC license), restyled — credit included in pack.

## What's inside (50 files)
- cw3_arrow-down.png (512x512 px)
- cw3_arrow-down.svg
- cw3_arrow-up-down.png (512x512 px)
- cw3_arrow-up-down.svg
- cw3_arrow-up.png (512x512 px)
- cw3_arrow-up.svg
- cw3_bridge.png (512x512 px)
- cw3_bridge.svg
- cw3_clock-arrow-up.png (512x512 px)
- cw3_clock-arrow-up.svg
- cw3_coins.png (512x512 px)
- cw3_coins.svg
- cw3_copy-check.png (512x512 px)
- cw3_copy-check.svg
- cw3_file-scan.png (512x512 px)
- cw3_file-scan.svg
- cw3_fuel.png (512x512 px)
- cw3_fuel.svg
- cw3_hand-coins.png (512x512 px)
- cw3_hand-coins.svg
- cw3_key-round.png (512x512 px)
- cw3_key-round.svg
- cw3_key.png (512x512 px)
- cw3_key.svg
- cw3_layers-arrow-up.png (512x512 px)
- cw3_layers-arrow-up.svg
- cw3_layers.png (512x512 px)
- cw3_layers.svg
- cw3_lock-keyhole.png (512x512 px)
- cw3_lock-keyhole.svg
- cw3_preview.png (900x690 px)
- cw3_scan-qr-code.png (512x512 px)
- cw3_scan-qr-code.svg
- cw3_scan.png (512x512 px)
- cw3_scan.svg
- cw3_search-check.png (512x512 px)
- cw3_search-check.svg
- cw3_send.png (512x512 px)
- cw3_send.svg
- cw3_shield-alert.png (512x512 px)
- cw3_shield-alert.svg
- cw3_shield-check.png (512x512 px)
- cw3_shield-check.svg
- cw3_shield-cog.png (512x512 px)
- cw3_shield-cog.svg
- cw3_shield.png (512x512 px)
- cw3_shield.svg
- cw3_wallet.png (512x512 px)
- cw3_wallet.svg
- cw3_LICENSE-lucide.txt

## License (short)
Free to use in personal and commercial projects. Do not resell or redistribute the files themselves. Full text: LICENSE.txt

## AI disclosure
Created with the help of generative AI (AI-generated graphics) by the AI crew of Starship Aurora / Noor Al Deen.

Made with love by the Starship Aurora crew.
