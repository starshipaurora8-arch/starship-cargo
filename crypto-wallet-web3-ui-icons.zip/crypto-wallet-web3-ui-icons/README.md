# Crypto Wallet & Web3 UI Icons

24 professional crypto/web3 UI icons from the Lucide library (ISC license), restyled with a unified crypto theme: single 2px stroke weight, 24px grid, blue primary (#2563EB) with purple accent (#7C3AED), light/dark friendly with subtle tile backgrounds. Includes wallet, send, receive, swap, key, shield, lock, QR code, charts, coins, gas, bridge, stake, NFT, contract, seed phrase, scan, history, settings, alert, check, copy, explorer. Delivered as 24 SVG source files + 512px PNG previews + preview sheet + license.

## What's inside (50 files)
- cw3_wallet.svg
- cw3_wallet.png (512x512 px)
- cw3_send.svg
- cw3_send.png (512x512 px)
- cw3_hand-coins.svg
- cw3_hand-coins.png (512x512 px)
- cw3_arrow-up-down.svg
- cw3_arrow-up-down.png (512x512 px)
- cw3_key.svg
- cw3_key.png (512x512 px)
- cw3_shield.svg
- cw3_shield.png (512x512 px)
- cw3_lock-keyhole.svg
- cw3_lock-keyhole.png (512x512 px)
- cw3_scan-qr-code.svg
- cw3_scan-qr-code.png (512x512 px)
- cw3_arrow-up.svg
- cw3_arrow-up.png (512x512 px)
- cw3_arrow-down.svg
- cw3_arrow-down.png (512x512 px)
- cw3_coins.svg
- cw3_coins.png (512x512 px)
- cw3_fuel.svg
- cw3_fuel.png (512x512 px)
- cw3_bridge.svg
- cw3_bridge.png (512x512 px)
- cw3_layers-arrow-up.svg
- cw3_layers-arrow-up.png (512x512 px)
- cw3_layers.svg
- cw3_layers.png (512x512 px)
- cw3_file-scan.svg
- cw3_file-scan.png (512x512 px)
- cw3_key-round.svg
- cw3_key-round.png (512x512 px)
- cw3_scan.svg
- cw3_scan.png (512x512 px)
- cw3_clock-arrow-up.svg
- cw3_clock-arrow-up.png (512x512 px)
- cw3_shield-cog.svg
- cw3_shield-cog.png (512x512 px)
- cw3_shield-alert.svg
- cw3_shield-alert.png (512x512 px)
- cw3_shield-check.svg
- cw3_shield-check.png (512x512 px)
- cw3_copy-check.svg
- cw3_copy-check.png (512x512 px)
- cw3_search-check.svg
- cw3_search-check.png (512x512 px)
- cw3_preview.png (900x690 px)
- cw3_LICENSE-lucide.txt

## License (short)
Free to use in personal and commercial projects. Do not resell or redistribute the files themselves. Full text: LICENSE.txt

## AI disclosure
Created with the help of generative AI (AI-generated graphics) by the AI crew of Starship Aurora / Noor Al Deen.

Made with love by the Starship Aurora crew.
