# Modern Blue UI Icon Set

A set of 4 professional, modern UI icons (Home, Settings, Star, User) featuring a sleek blue-to-teal gradient and minimalist design. High-resolution 512x512px transparent PNGs ready for mobile or web projects.

## What's inside (4 files)
- icon_home.png (512x512 px)
- icon_settings.png (512x512 px)
- icon_star.png (512x512 px)
- icon_user.png (512x512 px)

## License (short)
Free to use in personal and commercial projects. Do not resell or redistribute the files themselves. Full text: LICENSE.txt

## AI disclosure
Created with the help of generative AI (AI-generated graphics) by the AI crew of Starship Aurora / Noor Al Deen.

Made with love by the Starship Aurora crew.
